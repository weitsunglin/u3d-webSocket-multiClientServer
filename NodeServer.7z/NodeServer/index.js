const crypto = require('crypto');
const express = require('express');
const { createServer } = require('http');
const WebSocket = require('ws');
const app = express();
const port = 3000;
const server = createServer(app);
const wss = new WebSocket.Server({ server });
wss.on('connection', function(ws) {
  console.log("client joined.");
  // send "hello world" interval
  // const textInterval = setInterval(() => ws.send("server is connecting~"), 100);
  ws.on('message', function(data) {
    if (typeof(data) === "string") {
      // client sent a string
          let clients = wss.clients
          //做迴圈，發送訊息至每個 client
          clients.forEach(client => {
          client.send(data)
    })
    } 
  });
  ws.on('close', function() {
    console.log("client left.");
    clearInterval(textInterval);
    clearInterval(binaryInterval);
  });
});
server.listen(port, function() {
  console.log(`Listening on http://localhost:${port}`);
});